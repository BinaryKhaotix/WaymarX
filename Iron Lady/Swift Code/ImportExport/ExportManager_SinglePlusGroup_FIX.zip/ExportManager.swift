//
//  ExportManager.swift
//  Iron Lady
//
//  Supports BOTH single-crum export and group export
//

import Foundation
import ZIPFoundation
import CoreData

struct ExportManager {

    // MARK: - Single Crumb Export (used by BreadcrumbDetailView)

    static func exportSingleCrumb(_ breadcrumb: Breadcrumb, completion: @escaping (URL?) -> Void) {
        let crumbExport = BreadcrumbExport(
            id: breadcrumb.id ?? UUID(),
            name: breadcrumb.name,
            city: breadcrumb.city,
            state: breadcrumb.state,
            streetAddress: breadcrumb.streetAddress,
            zipCode: breadcrumb.zipCode,
            dateDropped: breadcrumb.dateDropped,
            latitude: breadcrumb.latitude,
            longitude: breadcrumb.longitude,
            isFavorite: breadcrumb.isFavorite,
            note: breadcrumb.note,
            photoURL: breadcrumb.photoURL
        )

        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            encoder.dateEncodingStrategy = .iso8601
            let jsonData = try encoder.encode(crumbExport)

            let tempDir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

            // breadcrumb.json
            let jsonURL = tempDir.appendingPathComponent("breadcrumb.json")
            try jsonData.write(to: jsonURL)

            // photo (if present)
            if let photoFileName = breadcrumb.photoURL,
               let docs = getDocumentsDirectory() {
                let source = docs.appendingPathComponent(photoFileName)
                if FileManager.default.fileExists(atPath: source.path) {
                    let dest = tempDir.appendingPathComponent(photoFileName)
                    if FileManager.default.fileExists(atPath: dest.path) {
                        try? FileManager.default.removeItem(at: dest)
                    }
                    try FileManager.default.copyItem(at: source, to: dest)
                }
            }

            let safeName = (breadcrumb.name?.isEmpty == false ? breadcrumb.name! : "Breadcrumb")
                .replacingOccurrences(of: "/", with: "-")

            let zipURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("\(safeName)-\(UUID().uuidString).zip")

            try FileManager.default.zipItem(at: tempDir, to: zipURL)
            try? FileManager.default.removeItem(at: tempDir)

            completion(zipURL)
        } catch {
            print("exportSingleCrumb error: \(error)")
            completion(nil)
        }
    }

    // MARK: - Group Export (ZIP with group.json + images)

    static func exportGroup(_ group: CrmGroup, completion: @escaping (URL?) -> Void) {
        do {
            let crumbs = extractBreadcrumbs(from: group)

            let groupExport = CrmGroupExport(
                id: group.id ?? UUID(),
                groupName: group.groupName,
                groupDescription: group.groupDescription,
                dateCreated: group.dateCreated,
                breadcrumbs: crumbs.map { crumb in
                    BreadcrumbExport(
                        id: crumb.id ?? UUID(),
                        name: crumb.name,
                        city: crumb.city,
                        state: crumb.state,
                        streetAddress: crumb.streetAddress,
                        zipCode: crumb.zipCode,
                        dateDropped: crumb.dateDropped,
                        latitude: crumb.latitude,
                        longitude: crumb.longitude,
                        isFavorite: crumb.isFavorite,
                        note: crumb.note,
                        photoURL: crumb.photoURL
                    )
                }
            )

            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            encoder.dateEncodingStrategy = .iso8601
            let jsonData = try encoder.encode(groupExport)

            let tempDir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

            // group.json
            let jsonURL = tempDir.appendingPathComponent("group.json")
            try jsonData.write(to: jsonURL)

            // copy photos (dedupe by filename)
            let uniquePhotos = Array(Set(crumbs.compactMap { $0.photoURL }))
            if let docs = getDocumentsDirectory() {
                for fileName in uniquePhotos {
                    let source = docs.appendingPathComponent(fileName)
                    guard FileManager.default.fileExists(atPath: source.path) else { continue }
                    let dest = tempDir.appendingPathComponent(fileName)
                    if FileManager.default.fileExists(atPath: dest.path) {
                        try? FileManager.default.removeItem(at: dest)
                    }
                    try FileManager.default.copyItem(at: source, to: dest)
                }
            }

            let safeName = (group.groupName?.isEmpty == false ? group.groupName! : "Group")
                .replacingOccurrences(of: "/", with: "-")

            let zipURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("\(safeName)-\(UUID().uuidString).zip")

            try FileManager.default.zipItem(at: tempDir, to: zipURL)
            try? FileManager.default.removeItem(at: tempDir)

            completion(zipURL)
        } catch {
            print("exportGroup error: \(error)")
            completion(nil)
        }
    }

    // MARK: - Helpers

    private static func extractBreadcrumbs(from group: CrmGroup) -> [Breadcrumb] {
        if let set = group.value(forKey: "breadcrumbs") as? Set<Breadcrumb> {
            return set.sorted { ($0.dateDropped ?? .distantPast) > ($1.dateDropped ?? .distantPast) }
        }
        if let set = group.value(forKey: "crumbs") as? Set<Breadcrumb> {
            return set.sorted { ($0.dateDropped ?? .distantPast) > ($1.dateDropped ?? .distantPast) }
        }
        return []
    }

    private static func getDocumentsDirectory() -> URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    }
}
